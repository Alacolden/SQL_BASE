﻿using System;
using System.Collections.Generic;


class Lab1
{


    static float F(float x) => x * x * x * x - 2 * x * x + 24 * x - 8;
    static float FPrime(float x) => 4 * x * x * x - 4 * x + 24;
    static float FDouble(float x) => 12 * x * x - 4;

    // ═══════════════════════════════════════════════════════════════
    //  Дополнительное уравнение п.3:  g(x) = x^2 + 100000x - 4 = 0
    //  Вариант 4 → v = 4
    // ═══════════════════════════════════════════════════════════════

    const int VARIANT = 4;
    static float G(float x) => x * x + 100000f * x - VARIANT;
    static float GPrime(float x) => 2 * x + 100000f;
    static float GDouble(float x) => 2f;

    // ───────────────────────────────────────────────────────────────
    //  Форматированный вывод заголовка
    // ───────────────────────────────────────────────────────────────
    static void Header(string text)
    {
        Console.WriteLine();
        Console.WriteLine(new string('═', 70));
        Console.WriteLine("  " + text);
        Console.WriteLine(new string('═', 70));
    }

    static void SubHeader(string text)
    {
        Console.WriteLine();
        Console.WriteLine("  ── " + text + " " + new string('─', Math.Max(0, 62 - text.Length)));
    }

    // ═══════════════════════════════════════════════════════════════
    //  1. МЕТОД ПОЛОВИННОГО ДЕЛЕНИЯ
    // ═══════════════════════════════════════════════════════════════
    /// <summary>
    /// Метод половинного деления. Требует f(a)*f(b) &lt; 0.
    /// Остановка: (b-a)/2 &lt; eps.
    /// </summary>
    static float Bisection(
        Func<float, float> f,
        float a, float b,
        float eps,
        out int iters,
        bool verbose = true)
    {
        if (f(a) * f(b) > 0)
            throw new ArgumentException($"f(a)·f(b) > 0 на [{a}, {b}] — корня нет.");

        iters = 0;
        float x = (a + b) / 2f;

        if (verbose)
        {
            Console.WriteLine($"\n  {"n",-5} {"a",-14} {"b",-14} {"x=(a+b)/2",-14} {"f(x)",-14} {"(b-a)/2",-14}");
            Console.WriteLine(new string('-', 78));
        }

        while ((b - a) / 2f >= eps)
        {
            x = (a + b) / 2f;
            float fx = f(x);

            if (verbose)
                Console.WriteLine($"  {iters,-5} {a,-14:F7} {b,-14:F7} {x,-14:F7} {fx,-14:E4} {(b - a) / 2f,-14:E4}");

            if (Math.Abs(fx) < 1e-30f) break;

            if (f(a) * fx < 0) b = x;
            else a = x;

            iters++;
        }
        return x;
    }

    // ═══════════════════════════════════════════════════════════════
    //  2. МЕТОД ПРОСТЫХ ИТЕРАЦИЙ
    // ═══════════════════════════════════════════════════════════════
    /// <summary>
    /// φ(x) = x - τ·f(x), τ = 1/max|f'(x)| на [a,b].
    /// Остановка:
    ///   q &lt; 0.5  →  |x_{n+1}-x_n| &lt; eps
    ///   q ≥ 0.5  →  q/(1-q)·|x_{n+1}-x_n| &lt; eps
    /// </summary>
    static float SimpleIteration(
        Func<float, float> f,
        Func<float, float> fPrime,
        float x0, float a, float b,
        float eps, int maxIter,
        out int iters,
        bool verbose = true)
    {
        // Оцениваем M = max|f'|, m = min|f'| на [a,b]
        int n = 500;
        float M = 0f, m = float.MaxValue;
        for (int i = 0; i <= n; i++)
        {
            float xi = a + i * (b - a) / n;
            float fp = Math.Abs(fPrime(xi));
            if (fp > M) M = fp;
            if (fp < m) m = fp;
        }
        float tau = 1f / M;
        float q = 1f - tau * m;
        if (q < 0) q = -q;

        if (verbose)
            Console.WriteLine($"\n  τ = {tau:F6},  M = {M:F4},  m = {m:F4},  q = {q:F6}");

        Func<float, float> phi = x => x - tau * f(x);

        if (verbose)
        {
            Console.WriteLine($"  {"n",-5} {"x_n",-17} {"x_{{n+1}}",-17} {"delta",-14} {"f(x_{{n+1}})",-14}");
            Console.WriteLine(new string('-', 78));
        }

        float xCurr = x0;
        iters = 0;

        for (int i = 0; i < maxIter; i++)
        {
            float xNext = phi(xCurr);
            float delta = Math.Abs(xNext - xCurr);
            float fNext = f(xNext);      // переиспользуем далее

            if (verbose)
                Console.WriteLine($"  {i,-5} {xCurr,-17:F10} {xNext,-17:F10} {delta,-14:E4} {fNext,-14:E4}");

            bool stop = q < 0.5f
                ? delta < eps
                : (q / (1f - q)) * delta < eps;

            xCurr = xNext;
            iters++;

            if (stop || float.IsNaN(xCurr) || float.IsInfinity(xCurr)) break;
        }
        return xCurr;
    }

    // ═══════════════════════════════════════════════════════════════
    //  3. МЕТОД НЬЮТОНА
    // ═══════════════════════════════════════════════════════════════
    /// <summary>
    /// x_{n+1} = x_n - f(x_n)/f'(x_n).
    /// Условие (1.4): |x_{n+1}-x_n| &lt; eps.
    /// Начальное приближение: f(x0)·f''(x0) > 0.
    /// </summary>
    static float Newton(
        Func<float, float> f,
        Func<float, float> fPrime,
        Func<float, float> fDouble,
        float a, float b,
        float eps, int maxIter,
        out int iters,
        float? forceX0 = null,    // для эксперимента с другим концом
        bool verbose = true)
    {
        float x0;
        if (forceX0.HasValue)
        {
            x0 = forceX0.Value;
            if (verbose)
                Console.WriteLine($"\n  [!] Принудительное x0 = {x0} (эксперимент)");
        }
        else
        {
            // Выбираем конец, где f(x)·f''(x) > 0
            x0 = (f(a) * fDouble(a) > 0) ? a : b;
        }

        if (verbose)
        {
            Console.WriteLine($"\n  Начальное приближение x0 = {x0}");
            Console.WriteLine($"  {"n",-5} {"x_n",-20} {"f(x_n)",-16} {"f'(x_n)",-14} {"delta",-14}");
            Console.WriteLine(new string('-', 78));
        }

        float xCurr = x0;
        iters = 0;

        for (int i = 0; i < maxIter; i++)
        {
            float fx = f(xCurr);
            float fpx = fPrime(xCurr);

            if (Math.Abs(fpx) < 1e-30f)
            {
                if (verbose) Console.WriteLine("  [!] f'(x) ≈ 0, метод расходится.");
                break;
            }

            float xNext = xCurr - fx / fpx;
            float delta = Math.Abs(xNext - xCurr);

            if (verbose)
                Console.WriteLine($"  {i,-5} {xCurr,-20:F12} {fx,-16:E6} {fpx,-14:F6} {delta,-14:E4}");

            xCurr = xNext;
            iters++;

            if (delta < eps || float.IsNaN(xCurr) || float.IsInfinity(xCurr)) break;
        }
        return xCurr;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Локализация всех корней сканированием
    // ═══════════════════════════════════════════════════════════════
    static List<(float a, float b)> FindBrackets(
        Func<float, float> f, float left, float right, int steps = 10000)
    {
        var brackets = new List<(float, float)>();
        float h = (right - left) / steps;
        float xPrev = left;
        float fPrev = f(xPrev);

        for (int i = 1; i <= steps; i++)
        {
            float xCurr = left + i * h;
            float fCurr = f(xCurr);
            if (fPrev * fCurr < 0)
                brackets.Add((xPrev, xCurr));
            xPrev = xCurr;
            fPrev = fCurr;
        }
        return brackets;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Эксперимент: минимальная сходящаяся точность
    // ═══════════════════════════════════════════════════════════════
    /// <summary>
    /// Уменьшает eps начиная с 1e-1 до тех пор, пока метод сходится
    /// (не NaN, не Inf, итераций меньше maxIter).
    /// </summary>
    static float FindMinEps(
        string methodName,
        Func<float, float, int, float> solve,   // (eps, x0, maxIter) -> root
        float x0, int maxIter = 200)
    {
        float epsTest = 1e-1f;
        float minWorkingEps = float.NaN;

        for (int step = 0; step < 20; step++)
        {
            try
            {
                float root = solve(epsTest, x0, maxIter);
                if (!float.IsNaN(root) && !float.IsInfinity(root))
                    minWorkingEps = epsTest;
                else
                    break;
            }
            catch { break; }

            epsTest /= 10f;
        }
        return minWorkingEps;
    }

    // ═══════════════════════════════════════════════════════════════
    //  MAIN
    // ═══════════════════════════════════════════════════════════════
    static void Main()
    {
        const float EPS = 1e-3f;
        const int MAXITER = 500;

        Header("Лабораторная работа №1. Вариант 4.");
        Console.WriteLine("  f(x) = x⁴ - 2x² + 24x - 8");
        Console.WriteLine("  f'(x)= 4x³ - 4x + 24");
        Console.WriteLine("  f''(x)= 12x² - 4");
        Console.WriteLine("  Точность eps = 1e-3,  тип данных: float (32 бит)");

        // ── Локализация корней ─────────────────────────────────────
        Header("1. Локализация корней на [-10, 10]");
        var brackets = FindBrackets(F, -10f, 10f);

        if (brackets.Count == 0)
        {
            Console.WriteLine("  Корни не найдены на [-10, 10].");
            return;
        }

        Console.WriteLine($"  Найдено отрезков со сменой знака: {brackets.Count}");
        for (int i = 0; i < brackets.Count; i++)
        {
            var (a, b) = brackets[i];
            Console.WriteLine($"  [{i + 1}]  [{a:F4}, {b:F4}]   f(a)={F(a):E3}  f(b)={F(b):E3}");
        }

        // ── Сводная таблица результатов ────────────────────────────
        var resultsNewton = new List<(float root, int iters)>();
        var resultsSI = new List<(float root, int iters)>();
        var resultsBisect = new List<(float root, int iters)>();

        // ── Обработка каждого корня ────────────────────────────────
        for (int k = 0; k < brackets.Count; k++)
        {
            var (a, b) = brackets[k];
            float midpoint = (a + b) / 2f;

            Header($"Корень #{k + 1}  на отрезке [{a:F4}, {b:F4}]");

            // ── Метод половинного деления ──────────────────────────
            SubHeader("Метод половинного деления");
            float rBis = Bisection(F, a, b, EPS, out int iBis);
            Console.WriteLine($"\n  Результат: x* = {rBis:F7},  f(x*) = {F(rBis):E4},  итераций: {iBis}");
            resultsBisect.Add((rBis, iBis));

            // ── Метод простых итераций — начало с середины ─────────
            SubHeader("Метод простых итераций  (x0 = середина отрезка)");
            float rSI = SimpleIteration(F, FPrime, midpoint, a, b, EPS, MAXITER, out int iSI);
            Console.WriteLine($"\n  Результат: x* = {rSI:F7},  f(x*) = {F(rSI):E4},  итераций: {iSI}");

            // ── МПИ — пробуем с левым концом ──────────────────────
            SubHeader($"Метод простых итераций  (x0 = левый конец {a:F4})");
            float rSIa = SimpleIteration(F, FPrime, a, a, b, EPS, MAXITER, out int iSIa);
            Console.WriteLine($"\n  Результат: x* = {rSIa:F7},  f(x*) = {F(rSIa):E4},  итераций: {iSIa}");

            // ── МПИ — пробуем с правым концом ─────────────────────
            SubHeader($"Метод простых итераций  (x0 = правый конец {b:F4})");
            float rSIb = SimpleIteration(F, FPrime, b, a, b, EPS, MAXITER, out int iSIb);
            Console.WriteLine($"\n  Результат: x* = {rSIb:F7},  f(x*) = {F(rSIb):E4},  итераций: {iSIb}");

            resultsSI.Add((rSI, iSI));

            // ── Метод Ньютона — нормальный x0 ─────────────────────
            SubHeader("Метод Ньютона  (x0 по условию f(x0)·f''(x0) > 0)");
            float rN = Newton(F, FPrime, FDouble, a, b, EPS, MAXITER, out int iN);
            Console.WriteLine($"\n  Результат: x* = {rN:F7},  f(x*) = {F(rN):E4},  итераций: {iN}");
            resultsNewton.Add((rN, iN));

            // ── Метод Ньютона — с другого конца (эксперимент) ─────
            float otherEnd = ((F(a) * FDouble(a) > 0) ? b : a);
            SubHeader($"Метод Ньютона  (x0 = другой конец {otherEnd:F4}, эксперимент)");
            Newton(F, FPrime, FDouble, a, b, EPS, MAXITER, out int iN2, forceX0: otherEnd);
            Console.WriteLine($"  (см. итерации выше — объяснение поведения в отчёте)");
        }

        // ── Итоговое сравнение ─────────────────────────────────────
        Header("Итоговое сравнение методов");
        Console.WriteLine($"  {"#",-4} {"Половинного дел.",-22} {"Простых итераций",-22} {"Ньютона",-22}");
        Console.WriteLine($"  {"",4} {"корень",-12}{"итер.",-10} {"корень",-12}{"итер.",-10} {"корень",-12}{"итер.",-10}");
        Console.WriteLine(new string('-', 72));
        for (int k = 0; k < brackets.Count; k++)
        {
            var (rb, ib) = resultsBisect[k];
            var (rs, is_) = resultsSI[k];
            var (rn, in_) = resultsNewton[k];
            Console.WriteLine($"  {k + 1,-4} {rb,-12:F6}{ib,-10} {rs,-12:F6}{is_,-10} {rn,-12:F6}{in_,-10}");
        }

        // ═══════════════════════════════════════════════════════════
        //  П.3 — Минимальная сходящаяся точность для f(x)
        // ═══════════════════════════════════════════════════════════
        Header("3а. Минимальная сходящаяся точность для f(x)");
        Console.WriteLine("  Уменьшаем eps (1e-1, 1e-2, ...) пока метод сходится корректно.\n");

        foreach (var (a, b) in brackets)
        {
            float mid = (a + b) / 2f;
            Console.WriteLine($"  Отрезок [{a:F4}, {b:F4}]:");

            // Метод половинного деления
            float epsBis = 1e-1f;
            float lastBis = float.NaN;
            for (int s = 0; s < 12; s++)
            {
                try
                {
                    float r = Bisection(F, a, b, epsBis, out _, verbose: false);
                    if (float.IsNaN(r) || float.IsInfinity(r)) break;
                    lastBis = r;
                }
                catch { break; }
                epsBis /= 10f;
            }
            epsBis *= 10f; // последнее рабочее
            Console.WriteLine($"    Половинного деления:  min eps ≈ {epsBis:E1},  x* = {lastBis:F7},  f(x*)={F(lastBis):E3}");

            // Метод простых итераций
            float epsSI = 1e-1f;
            float lastSI = float.NaN;
            for (int s = 0; s < 12; s++)
            {
                try
                {
                    float r = SimpleIteration(F, FPrime, mid, a, b, epsSI, 500, out _, verbose: false);
                    if (float.IsNaN(r) || float.IsInfinity(r)) break;
                    lastSI = r;
                }
                catch { break; }
                epsSI /= 10f;
            }
            epsSI *= 10f;
            Console.WriteLine($"    Простых итераций:     min eps ≈ {epsSI:E1},  x* = {lastSI:F7},  f(x*)={F(lastSI):E3}");

            // Метод Ньютона
            float epsN = 1e-1f;
            float lastN = float.NaN;
            float x0N = (F(a) * FDouble(a) > 0) ? a : b;
            for (int s = 0; s < 12; s++)
            {
                try
                {
                    float r = Newton(F, FPrime, FDouble, a, b, epsN, 500, out _, verbose: false);
                    if (float.IsNaN(r) || float.IsInfinity(r)) break;
                    lastN = r;
                }
                catch { break; }
                epsN /= 10f;
            }
            epsN *= 10f;
            Console.WriteLine($"    Ньютона:              min eps ≈ {epsN:E1},  x* = {lastN:F7},  f(x*)={F(lastN):E3}");
        }

        // ═══════════════════════════════════════════════════════════
        //  П.3 — Уравнение g(x) = x^2 + 100000x - 4 = 0
        // ═══════════════════════════════════════════════════════════
        Header("3б. Уравнение g(x) = x² + 100000x - 4 = 0  (v=4)");
        Console.WriteLine("  Дискриминант D = 100000² + 16 = 10000000016");
        Console.WriteLine("  Корни: x = (-100000 ± √10000000016) / 2");
        Console.WriteLine("  Положительный корень x* ≈ 4e-5  (очень малый!)");
        Console.WriteLine();
        Console.WriteLine("  [!] Проблема: при вычислении на float (7 знаков) разность");
        Console.WriteLine("      100000² и 100000²+16 может не различаться!");
        Console.WriteLine("      Это классическая потеря значимости при вычитании.\n");

        // Локализация положительного корня
        var brackG = FindBrackets(G, -1f, 1f, 100000);

        if (brackG.Count == 0)
        {
            Console.WriteLine("  [!] Положительный корень не локализован на float — потеря значимости!");
            Console.WriteLine("      g(0) = {0:E4},  g(1) = {1:E4}", G(0f), G(1f));
        }
        else
        {
            Console.WriteLine($"  Найдены отрезки:");
            foreach (var (a, b) in brackG)
                Console.WriteLine($"    [{a:E4}, {b:E4}]  g(a)={G(a):E3}  g(b)={G(b):E3}");

            foreach (var (a, b) in brackG)
            {
                Console.WriteLine($"\n  Решаем на [{a:E4}, {b:E4}]:");

                Console.WriteLine("  Половинного деления:");
                float rBG = Bisection(G, a, b, EPS, out int iBG, verbose: true);
                Console.WriteLine($"  x* = {rBG:E7},  g(x*) = {G(rBG):E4},  итераций: {iBG}");

                Console.WriteLine("\n  Ньютона:");
                float rNG = Newton(G, GPrime, GDouble, a, b, EPS, MAXITER, out int iNG, verbose: true);
                Console.WriteLine($"  x* = {rNG:E7},  g(x*) = {G(rNG):E4},  итераций: {iNG}");

                // Минимальная eps для g(x)
                Console.WriteLine("\n  Минимальная eps для g(x):");
                float epsGBis = 1e-1f, lastGBis = float.NaN;
                for (int s = 0; s < 12; s++)
                {
                    try
                    {
                        float r = Bisection(G, a, b, epsGBis, out _, verbose: false);
                        if (float.IsNaN(r) || float.IsInfinity(r)) break;
                        lastGBis = r;
                    }
                    catch { break; }
                    epsGBis /= 10f;
                }
                epsGBis *= 10f;
                Console.WriteLine($"    Половинного деления:  min eps ≈ {epsGBis:E1},  x* = {lastGBis:E7}");

                float epsGN = 1e-1f, lastGN = float.NaN;
                for (int s = 0; s < 12; s++)
                {
                    try
                    {
                        float r = Newton(G, GPrime, GDouble, a, b, epsGN, 500, out _, verbose: false);
                        if (float.IsNaN(r) || float.IsInfinity(r)) break;
                        lastGN = r;
                    }
                    catch { break; }
                    epsGN /= 10f;
                }
                epsGN *= 10f;
                Console.WriteLine($"    Ньютона:              min eps ≈ {epsGN:E1},  x* = {lastGN:E7}");
            }
        }

        Console.WriteLine();
        Console.WriteLine("  Вывод по п.3: минимальная eps ограничена точностью float (~7 знаков).");
        Console.WriteLine("  Для g(x) потеря значимости при вычислении √D делает float");
        Console.WriteLine("  практически неприменимым — нужен double или аналитическая форма.");

        Console.WriteLine("\nНажмите любую клавишу...");
        Console.ReadKey();
    }
}